module.exports = function(casper, scenario, vp) {
  casper.echo('onReady.js', 'INFO');
  casper.evaluate(function(){

  });
  casper.wait(50);
};
